<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Members Profile</title>
  <?php include_once('head.php'); ?>
  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">  

</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">3</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Brad Diesel
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can...</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user8-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  John Pierce
                  <span class="float-right text-sm text-muted"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">I got your message bro</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user3-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Nora Silvester
                  <span class="float-right text-sm text-warning"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">The subject goes here</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 new messages
            <span class="float-right text-muted text-sm">3 mins</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 friend requests
            <span class="float-right text-muted text-sm">12 hours</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 days</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
  <?php include_once('sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Members</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Members</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

   
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="dist/img/ff.jpg"
                       alt="User profile picture">
                </div>

                <?php
                  include_once('database_connection.php');
                  $mem_id = $_GET['mid'];
                  $sql = "SELECT id,fullname,member_id,telephone,dob,residense_address,status,position,next_of_kin,YEAR(dob) as year,alter_call,marital_status,gender,occupation,spouse,number_of_children,city,region,postal_address from  members WHERE member_id='$mem_id' ORDER BY fullname ASC";
                  $result = mysqli_query($con, $sql);
                  if ($result) {
                    while ($row = mysqli_fetch_array($result)) {
                      $id = $row['id'];
                      $member_id = $row['member_id'];
                      $fullname = $row['fullname'];
                      $telephone = $row['telephone'];
                      $residence_address = $row['residense_address'];
                      $status = $row['status'];
                      $position = $row['position'];
                      $next_of_kin = $row['next_of_kin'];
                      $dob = $row['dob'];
                      $old_year = $row['year'];
                      $alter_call = $row['alter_call'];
                      $marital_status = $row['marital_status'];
                      $gender = $row['gender'];
                      $occupation = $row['occupation'];
                      $spouse = $row['spouse'];
                      $children = $row['number_of_children'];
                      $city = $row['city'];
                      $region = $row['region'];
                      $postal_address = $row['postal_address'];

                      $current_year = Date('Y');

                      $current_age = $current_year - $old_year;


           
                  ?>

                <h3 class="profile-username text-center"><?php echo $fullname; ?></h3>

                <p class="text-muted text-center"><?php echo $residence_address; ?> </p>

                <ul class="list-group list-group-unbordered mb-3">
                 
                  <li class="list-group-item">
                    <b>Position</b> <a class="float-right"><?php echo $position; ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Status </b> <a class="float-right"> <i class='fa-regular fa-circle-check' style='color:green'></i> <?php echo $status; ?> </a>
                  </li>
                </ul>

                <a href="edit_profile.php? idd=<?php echo $mem_id ?>" class="btn btn-primary btn-block"><i class="fa-solid fa-pen"></i> <b>Edit Profile</b></a>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">About Me</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              

              
                <strong><i class="fas fa-map-marker-alt mr-1"></i> Location</strong>

                <p class="text-muted"><?php echo $residence_address; ?></p>

                <hr>

                <strong><i class="fa-solid fa-phone mr-1"></i> Telephone</strong>

                <p class="text-muted">
                  <span class="tag tag-danger"><?php echo $telephone; ?></span>
                  
                
                </p>

                <hr>

                <strong><i class="fa-solid fa-user-group mr-1"></i> Next of kin</strong>

                <p class="text-muted"><?php echo $next_of_kin; ?></p>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card card-primary card-outline">
              
              <div class="card-body">
                
                 <table class="table">

                  <tr>
                    <td style="text-align:right"><b>Name:</b></td>
                    <td><?php echo $fullname; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Date of Birth:</b></td>
                    <td><?php echo $dob; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Age:</b></td>
                    <td><?php echo $current_age; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Date of 'Alter Call':</b></td>
                    <td><?php echo $alter_call; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Gender:</b></td>
                    <td><?php echo $gender; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Marital Status:</b></td>
                    <td><?php echo $marital_status; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Occupation:</b></td>
                    <td><?php echo $occupation; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Telephone:</b></td>
                    <td><?php echo $telephone; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Spouse Name:</b></td>
                    <td><?php echo $spouse; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Number of Children:</b></td>
                    <td><?php echo $children; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>City/Town:</b></td>
                    <td><?php echo $city; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Region:</b></td>
                    <td><?php echo $region; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Residence Address:</b></td>
                    <td><?php echo $residence_address; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Postal Address:</b></td>
                    <td><?php echo $postal_address ?></td>
                  </tr>
                  <tr>
                    <td style="text-align:right"><b>Next of Kin:</b></td>
                    <td><?php echo $next_of_kin; ?></td>
                  </tr>
                   <?php    }
                  } else {
                    echo "<script>swal('Error', 'No Record Found!', ' error'); </script>";
                  } ?>
                 </table>
               
                 

              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 <?php include_once('footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->



<?php include_once("script.php"); ?>


</body>
</html>
