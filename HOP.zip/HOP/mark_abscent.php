<?php 
include_once('database_connection.php');


$member_name = mysqli_real_escape_string($con,$_POST['member_name']);
$member_id = mysqli_real_escape_string($con,$_POST['member_id']);
$month = Date('M');
$Week = Date('W');
$Year = Date('Y');
$date_created = date("Y-M-jS");

$abscent= "Abscent";




$sqlc = " SELECT *  FROM attendance WHERE member_id='$member_id' and month='$month' and year='$Year' and week='$Week'";
$run = mysqli_query($con, $sqlc);
if (mysqli_num_rows($run) > 0) {

    $query = "UPDATE attendance SET status='$abscent' WHERE  member_id='$member_id' and month='$month' and year='$Year' and week='$Week' and date_created='$date_created' ";
    $pros = mysqli_query($con,$query);
    if($pros === true){
        echo "Attendance Updated";
    }else{
        echo mysqli_error($con);
    }

} else {

$sql = "INSERT INTO attendance(fullname,member_id,week,month,year,status,date_created) VALUES('$member_name','$member_id','$Week','$month','$Year','$abscent','$date_created')";
$execute = mysqli_query($con,$sql);
if($execute === true){
    echo "Attendance Recorded";
}else{
    echo mysqli_error($con);
}
}
?>