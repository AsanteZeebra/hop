<?php 
include_once('database_connection.php');

$idd = mysqli_real_escape_string($con,$_POST['member_id']);

$sql = "DELETE FROM members WHERE member_id='$idd' ";
$execute = mysqli_query($con,$sql);
if($execute === true){
    echo "SUCESSFULY DELETED";
}else {
    echo mysqli_error($con);
}

?>