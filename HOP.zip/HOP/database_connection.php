<?php
$hostname = "localhost";
$username = "root";
$password = "0249kwaku";  
$database = "hop";   
$con=mysqli_connect($hostname,$username,$password,$database);    
?>   