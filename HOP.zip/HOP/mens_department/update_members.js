$(function () {
  var Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
  });

  $(".upbtn").click(function () {
    update_member();
  });

  //function to update member info
  function update_member() {
    var fd = new FormData();

    var fullname = $(".tfname").val();
    var datebirth = $(".tfdob").val();
    var altercall = $(".tfalter").val();
    var gender = $(".cbgender").val();
    var marital = $(".cbmarital").val();
    var age = $(".tfage").val();
    var occupation = $(".tfoccupation").val();
    var telephone = $(".tftel").val();
    var spouse = $(".tfspouse").val();
    var children = $(".tfchild").val();
    var city = $(".tfcity").val();
    var region = $(".tfregion").val();
    var resience = $(".tfresidence").val();
    var postal = $(".tfpostal").val();
    var nextofkin = $(".tfnextofkin").val();
    var position = $(".tfposition").val();
    var member_id = $(".tfid").val();

    fd.append("fullname", fullname);
    fd.append("birthdate", datebirth);
    fd.append("altercall", altercall);
    fd.append("gender", gender);
    fd.append("marital", marital);
    fd.append("age", age);
    fd.append("occupation", occupation);
    fd.append("telephone", telephone);
    fd.append("spouse", spouse);
    fd.append("child", children);
    fd.append("city", city);
    fd.append("region", region);
    fd.append("residence", resience);
    fd.append("postal", postal);
    fd.append("nextofkin", nextofkin);
    fd.append("position", position);
    fd.append("member_id", member_id);

    $.ajax({
      url: "update_members.php",
      type: "POST",
      data: fd,
      contentType: false,
      cache: false,
      //dataType:"JSON",
      processData: false,
      success: function (data) {
        if (data != 0) {
          Toast.fire({
            icon: "success",
            title: data,
          });
        } else {
          Toast.fire({
            icon: "error",
            title: "Unable to Update Information",
          });
        }

        if (data != 0) {
            setTimeout(function() {
                location.reload();
            }, 1000)
        }
      },
      error: function (err) {
        alert("In error: " + err.responseText);
      },
    });
  }



  $('.delbtn').click(function () {
    delete_member();
  });

  //function to delete member info
  function delete_member() {
    var ff = new FormData();


    var id = $(".tfid").val();

    ff.append("member_id", id);

    $.ajax({
      url: "delete_profile.php",
      type: "POST",
      data: ff,
      contentType: false,
      cache: false,
      //dataType:"JSON",
      processData: false,
      success: function (data) {
        if (data != 0) {
          Toast.fire({
            icon: "success",
            title: data,
          });
        
        } else {
          Toast.fire({
            icon: "error",
            title: "Unable to delete Information",
          });
        }

        if (data != 0) {
            setTimeout(function() {
                location.reload();
            }, 1000)
        }
        window.location.href = "members_list.php";
      },
      error: function (err) {
        alert("In error: " + err.responseText);
      },
    });
  }

});
