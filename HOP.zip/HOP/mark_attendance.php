<?php  
include_once('database_connection.php');

$member_name = mysqli_real_escape_string($con,$_POST['member_name']);
$member_id = mysqli_real_escape_string($con,$_POST['member_id']);
$month = mysqli_real_escape_string($con,$_POST['month']);
$week = mysqli_real_escape_string($con,$_POST['week']);
$Year = mysqli_real_escape_string($con,$_POST['year']);
$date_created = date("Y-F-jS");
$status = "Present";
$fullweek = "week$week";

$sqlc = " SELECT *  FROM attendance WHERE member_id='$member_id' and month='$month' and year='$Year' and week='$week'";
$run = mysqli_query($con, $sqlc);
if (mysqli_num_rows($run) > 0) {

  $query = "UPDATE attendance SET status='Present' WHERE  member_id='$member_id' and month='$month' and year='$Year' and week='$week' ";
  $pros = mysqli_query($con,$query);
  if($pros === true){
      echo "Attendance Record Updated";
  }else{
      echo mysqli_error($con);
  }

} else {

$sql = "INSERT INTO attendance(fullname,member_id,week,month,year,status) VALUES('$member_name','$member_id','$week','$month','$Year','$status')";

$execute = mysqli_query($con,$sql);
if($execute === true){
    echo "Attendance Record Saved";
}else{
    echo mysqli_error($con);
}
}
?>

