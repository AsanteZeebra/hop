<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Blank Page</title>
  <?php include_once('head.php'); ?>
  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">  

</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="../../index3.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">3</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="../../dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Brad Diesel
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can...</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="../../dist/img/user8-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  John Pierce
                  <span class="float-right text-sm text-muted"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">I got your message bro</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="../../dist/img/user3-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Nora Silvester
                  <span class="float-right text-sm text-warning"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">The subject goes here</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 new messages
            <span class="float-right text-muted text-sm">3 mins</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 friend requests
            <span class="float-right text-muted text-sm">12 hours</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 days</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
  <?php include_once('sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 style="margin-left:100px">Member Registration Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Registration</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>



    
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
    <div class="row" style="justify-content:center">

 <div class="col-10" >
  <div class="card card-primary">
  <div class="card-header">
  <h3 class="card-title">Please fill all relevant spaces</h3>
  </div>
    <div class="card-body">

  <form method="post" id="member_form">
  <div class="row">
          <div class="col-md-12">
            <div class="card card-default">
              
              </div>
              <div class="card-body p-0">
                <div class="bs-stepper">
                  <div class="bs-stepper-header" role="tablist">
                     <!-- your steps here -->
                     <div class="step" data-target="#logins-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="logins-part" id="logins-part-trigger">
                        <span class="bs-stepper-circle"><i class="fa-regular fa-user"></i></span>
                        <span class="bs-stepper-label">Personal information</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#information-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="information-part" id="information-part-trigger">
                        <span class="bs-stepper-circle"><i class="fa-solid fa-users"></i></span>
                        <span class="bs-stepper-label">Family information</span>
                      </button>
                    </div>
                  </div>
                  <div class="bs-stepper-content">
                    <!-- your steps content here -->
                    <div id="logins-part" class="content" role="tabpanel" aria-labelledby="logins-part-trigger">
                      <div class="form-group">
                        <label>FullName</label>
                        <input type="text" class="form-control tfname" name="fullname"  placeholder="Enter FullName">
                      </div>

                      <div class="row">
                      <div class="col-4">
                    <div class="form-group">
                  <label>Date of Birth:</label>
                  
                        <input type="date" class="form-control  tfdob" name="dob">
                       
                    </div>
                    </div>

                    <div class="col-4">
                      <div class="form-group">
                       <label for="">Age:</label>
                       <input type="text" class="form-control tfage" name="age" placeholder="Age" >
                      </div>
                    </div>

                    <div class="col-4">
                    <div class="form-group">
                  <label>Date of 'Alter call':</label>
                   <input type="date" class="form-control tfalter" name="altercall">
                    </div>
                    </div>

                    </div>
                    
                     <div class="row">
                       <div class="col-6">
                       <div class="form-group">
                        <label for="">Gender</label>
                       <select class="form-control cbgender" name="gender">
                    <option value="" selected="selected"> --Gender--</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                      </div>
                       </div>

                      
                       <div class="col-6">
                       <div class="form-group">
                        <label for="">Marital Status</label>
                       <select class="form-control cbmarital" name="marital">
                    <option value="" selected="selected"> --Marital Status--</option>
                    <option value="Single">Single</option>
                    <option Vaalue="Married">Married</option>  
                    <option valaue="Divorced">Divorced</option>   
                    <option valaue="Widowed">Widowed</option>               
                  </select>
                      </div>
                       </div>
                     </div>
                       
                     <div class="row">
                      <div class="col-6">
                        <div class="form-group">
                          <label for="">Occupation</label>
                          <input type="text" class="form-control tfoccupation" placeholder="Occupation" name="occupation">
                        </div>
                      </div>

                      <div class="col-6">
                        <div class="form-group">
                          <label for="">Telephone</label>
                          <input type="tel" class="form-control tftel" placeholder="Telephone" name="telephone">
                        
                        </div>
                      </div>


                     </div>
                     
                      <button type="button" class="btn btn-primary nextbtn" onclick="stepper.next()">Next</button>
                    </div>
                    <div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger">
                      
                     
                    <div class="form-group">
                        <label for="exampleInputPassword1">Spouse Name</label>
                        <input type="text" class="form-control tfspouse"  placeholder="Name of Husband / Wife" name="spouse">
                      </div>

                      <div class="row">
                        <div class="col-4">
                          <div class="form-group">
                            <label for="">No. of Children</label>
                            <input type="text" class="form-control tfchild" placeholder="Number of children" name="children">
                          </div>
                        </div>

                        <div class="col-4">
                          <div class="form-group">
                            <label for="">City/Town</label>
                            <input type="text" class="form-control tfcity" placeholder="City/Town" name="city">
                          </div>
                        </div>

                        <div class="col-4">
                          <div class="form-group">
                            <label for="">Region</label>
                            <input type="text" class="form-control tfregion" placeholder="Region" name="region">
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-8">
                          <div class="form-group">
                           <label for="">Residence Address</label>
                           <textarea class="form-control tfresidence"   cols="30" rows="3" placeholder="House address" name="houseaddress"></textarea>
                          </div>
                        </div>

                        <div class="col-4">
                          <div class="form-group">
                           <label for="">Postal Address</label>
                           <textarea class="form-control tfpostal"  cols="30" rows="3" placeholder="P.O.Box" name="postbox"></textarea>
                          </div>
                        </div>
                      </div>  
                       
                      <div class="col-12">
                        <div class="form-group">
                          <label for="">Next of kin:</label>
                          <input type="text" class="form-control tfnextofkin" placeholder="Next of kin" name="nextofkin">
                        </div>
                      </div>
                      <button type="button" class="btn btn-primary" onclick="stepper.previous()">Previous</button>
                      <button type="submit"  class="btn btn-primary">Submit</button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-body -->
             
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
       
  </form>

      </div>
  </div>
</div>
  </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 <?php include_once('footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php include_once("script.php"); ?>

<script src="validate_member.js"></script>

<script>
  
</script>
</body>
</html>
