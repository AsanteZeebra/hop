 <!-- Main Footer -->
 <footer class="main-footer">
    <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="#">Fremike Tech</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>House of Power Ministries</b> Tema
    </div>
  </footer>
