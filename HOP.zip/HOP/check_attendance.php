
<?php 

include_once('database_connection.php');

$month = date('F');
$year = date('Y');
$week = date('W');
$fullweek= "week$week";

$sqlc = " SELECT *  FROM attendance where month='$month' AND year='$year' AND week='$fullweek' ";
$run = mysqli_query($con, $sqlc);
if (mysqli_num_rows($run) > 0) {


} else {
    $sql = "INSERT INTO attendance (member_id, fullname)  SELECT member_id, fullname FROM members ";
    $run = mysqli_query($con,$sql);
    
    $upd = "UPDATE attendance SET month='$month', year='$year',status='Absent', week='$fullweek' where month='' AND year='' ";
    $r = mysqli_query($con,$upd);

}
?>