<?php 
include_once('database_connection.php');

$idd = mysqli_real_escape_string($con,$_POST['member_id']);
$month = mysqli_real_escape_string($con,$_POST['month']);
$year = mysqli_real_escape_string($con,$_POST['year']);

$sql = "DELETE FROM dues WHERE member_id='$idd'  AND month='$month' AND year='$year' ";
$execute = mysqli_query($con,$sql);
if($execute === true){
    echo "Transaction Deleted Successfully";
}else {
    echo mysqli_error($con);
}

?>