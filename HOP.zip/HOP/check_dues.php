
<?php 

include_once('database_connection.php');

$month = date('F');
$year = date('Y');



$sqlc = " SELECT *  FROM dues where month='$month' AND year='$year' ";
$run = mysqli_query($con, $sqlc);
if (mysqli_num_rows($run) > 0) {


} else {
    $sql = "INSERT INTO dues (member_id, fullname)  SELECT member_id, fullname FROM members ";
    $run = mysqli_query($con,$sql);
    
    $upd = "UPDATE dues SET month='$month', year='$year',status='Unpaid',amount='0' where month='' AND year='' ";
    $r = mysqli_query($con,$upd);

}
?>